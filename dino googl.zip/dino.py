import os
import pygame
import random
import time

def load_image(name, colorkey=None):
    fullname = os.path.join('dino', name)
    image = pygame.image.load(fullname).convert()
    return image


WHITE = (255, 255, 255)
clock =  pygame.time.Clock() 
clock.tick(50)
pygame.init()
size = width, height = 1000, 600
screen = pygame.display.set_mode(size)
screen.fill(pygame.Color('White'))
running = True
all_sprites = pygame.sprite.Group()
sprite = pygame.sprite.Sprite()
i = 0
y = 0
spi = []
nogat = 0
class Dino(pygame.sprite.Sprite):
    i = 0
    y = 0
    image = load_image("ctoit.jpg")
    image_ctoit = load_image("ctoit.jpg")
    image_ctoit2 = load_image("ctoit2.jpg")
    image_ctoit3 = load_image("ctoit3.jpg")
    image_leg = load_image("leg.jpg")
    image_leg2 = load_image("leg2.jpg")
    

    def __init__(self, group):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite. Это очень важно !!!
        super().__init__(group)
        self.image = Dino.image
        self.rect = self.image.get_rect()
        self.rect.x = 100
        self.rect.y = 250
        self.y = 0
        self.ix = 6
        self.koln = 0
        
    def update(self, *arg):
        spi.append(self.rect)
        
        if self.y == 0 and self.koln == 0:
            self.rect.y = 250
            if i % 3 == 0:
                self.image = self.image_ctoit
            elif i % 3 == 1:
                self.image = self.image_ctoit3
            else:
                self.image = self.image_ctoit2
        
        
        
        if self.koln == 1:
             if i % 2 == 0:
                self.image = self.image_leg
             elif i % 2 == 1:
                self.image = self.image_leg2
#------------------------------
        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP] and self.y == 0:
            self.y = 1
            self.iz = 6
        
        if self.y == 1:
            self.rect.y -= self.iz
            self.iz -= 0.09
            if self.rect.y - self.iz > 250:
                self.rect.y = 250
                self.iz = 6
                self.y = 0

            

#----------------------------------------------------------

Dino(all_sprites)
class k(pygame.sprite.Sprite):
    i = 0
    y = 0
    image_kk = load_image("kaktyc.jpg")
    image_k1 = load_image("kaktyc.jpg")
    image_k2 = load_image("kaktyc2.jpg")
    image_k3 = load_image("kaktyc3.jpg")
    image_k4 = load_image("kaktyc4.jpg")
    

    def __init__(self, group):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite. Это очень важно !!!
        super().__init__(group)
        self.image = k.image_k1
        self.rect = self.image.get_rect()
        
        self.rect.x = 1000
        self.rect.y = 280
        self.c = 2.5
      
    def update(self, *arg):
        if self.rect.colliderect(spi[len(spi) - 1]):
            print('пересечение')
        self.rect.x -= self.c
        if self.rect.x < -100:
            self.rect.x = 1000
            self.r = random.randint(0, 3)
            if self.r == 0:
                self.image = self.image_k1
            if self.r == 1:
                self.image = self.image_k2
            if self.r == 2:
                self.image = self.image_k3
            if self.r == 3:
                self.image = self.image_k4
            self.c += 0.15

        
       
    def d():
        font = pygame.font.Font(None, 50)
        text = font.render(str(tim), 1, (255, 255, 255))
        screen.blit(text, (500, 100))
    
    
        
k(all_sprites)    
t = time.time()
while running:
    screen.fill((0, 0, 0))
    keys = pygame.key.get_pressed()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYUP and nogat == 1 :
            nogat = 0
            print('qqqqqqqqqqqqqqqqqqq')
        if keys[pygame.K_DOWN]:
            print('rrrrrr')
            nogat = 1
    print(nogat)
    
    i += 1
    all_sprites.draw(screen)
    all_sprites.update(event)
    t1 = time.time()
    pygame.draw.line(screen, WHITE, [0, 348],  [1000, 348],  5 )
    tim = (t1 - t) // 1 * 1
    k.d()
    time.sleep(0.01)
    pygame.display.flip()
#    if tim * 10 == 100:
#        running = False
#======================================================
'''
size = width, height = 600, 300
screen = pygame.display.set_mode(size)
screen.fill(pygame.Color('Black'))
running = True
all_sprites = pygame.sprite.Group()
sprite = pygame.sprite.Sprite()
sprite.image = load_image("gameover.png")
sprite.rect = sprite.image.get_rect()
all_sprites.add(sprite)

sprite.rect.x = -600
sprite.rect.y = 0

pygame.mouse.set_visible(False)
clock =  pygame.time.Clock() 
clock.tick(20)
i = 0
while running:
    screen.fill((0, 0, 255))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    if sprite.rect.x < 0:
        sprite.rect.x += 5
    all_sprites.draw(screen)
    pygame.display.flip()
    clock.tick(20)


pygame.quit()
'''
pygame.quit()